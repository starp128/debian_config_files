/* null version of <netdb.h> - <sys/socket.h> has everything */

/* arch-tag: 237ba543-97e2-4bd5-9c9c-32271d955eb1
   (do not change this comment) */
